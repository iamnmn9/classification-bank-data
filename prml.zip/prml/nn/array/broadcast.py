import numpy as np
from prml.nn.function import Function, broadcast, broadcast_to
